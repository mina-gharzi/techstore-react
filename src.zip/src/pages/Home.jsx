import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useProducts } from "../context/ProductsContext";
import { useCategories } from "../context/CategoriesContext";
import { usePageTitle } from "../hooks/usePageTitle";
import ProductCard from "../components/product/ProductCard";

// ======================================================
// آیکون‌های SVG
// ======================================================
const iconPaths = {
  arrowLeft: (
    <>
      <path d="M19 12H5" />
      <path d="m12 19-7-7 7-7" />
    </>
  ),
};

function Icon({ name, size = 20 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name] || null}
    </svg>
  );
}

// ======================================================
// انیمیشن ورود هنگام اسکرول
// ======================================================
function Reveal({ children, delay = 0, style, className }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(26px)",
        transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ======================================================
// کامپوننت‌های مشترک
// ======================================================
function SectionHeader({ title, subtitle }) {
  return (
    <div style={{ textAlign: "center", marginBottom: "40px" }}>
      <h2
        style={{
          fontSize: "clamp(1.6rem, 3vw, 2rem)",
          fontWeight: 800,
          color: "var(--color-text)",
          marginBottom: "10px",
        }}
      >
        {title}
      </h2>
      <p
        style={{
          color: "var(--color-text-muted)",
          fontSize: "var(--font-size-xl)",
        }}
      >
        {subtitle}
      </p>
    </div>
  );
}

function ProductSection({ bg, title, subtitle, products, to, cta }) {
  return (
    <section
      className="home-section"
      style={{ padding: "80px 20px", background: bg }}
    >
      <div className="container--plain">
        <Reveal>
          <SectionHeader title={title} subtitle={subtitle} />
        </Reveal>
        <Reveal delay={120}>
          <div
            className="home-product-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
              gap: "24px",
            }}
          >
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: "40px" }}>
            <Link
              to={to}
              className="btn-outline"
              style={{
                display: "inline-block",
                padding: "13px 32px",
                background: "var(--color-bg-white)",
                color: "var(--color-primary)",
                border: "1.5px solid var(--color-primary)",
                borderRadius: "14px",
                fontWeight: 700,
                textDecoration: "none",
                boxShadow: "var(--shadow-button-outline)",
              }}
            >
              {cta}
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ======================================================
// Hero — عکس پس‌زمینه تمام‌صفحه
// ======================================================
function HeroSection() {
  return (
    <section
      className="hero-section"
      style={{
        position: "relative",
        minHeight: "92vh",
        display: "flex",
        alignItems: "center",
        overflow: "hidden",
      }}
    >
      {/* تصویر پس‌زمینه */}
      <div
        className="hero-bg"
        style={{ position: "absolute", inset: 0, zIndex: 0 }}
      >
        <img
          src="https://images.unsplash.com/photo-1758467700789-d6f49099c884?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
          alt=""
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: "block",
          }}
        />
      </div>

      {/* اورلی آبی — بالا/چپ تیره‌تر برای خوانایی متن */}
      <div
        className="hero-overlay"
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 1,
          pointerEvents: "none",
          background:
            "linear-gradient(90deg, rgba(13,27,62,0.9) 0%, rgba(30,58,138,0.6) 50%, rgba(15,23,42,0.3) 100%)",
        }}
      />

      <div
        className="hero-container"
        style={{
          position: "relative",
          zIndex: 2,
          width: "100%",
          maxWidth: "1180px",
          margin: "0 auto",
          padding: "110px 40px 90px",
        }}
      >
        <div style={{ maxWidth: "620px" }}>
          <Reveal>
            {/* متا */}
            <div
              className="hero-meta"
              style={{
                display: "flex",
                alignItems: "center",
                gap: "14px",
                color: "rgba(255,255,255,0.8)",
                fontSize: "0.8rem",
                fontWeight: 700,
                letterSpacing: "0.12em",
                marginBottom: "30px",
              }}
            >
              <span>فروشگاه آنلاین تکنولوژی</span>
              <span
                style={{
                  width: "48px",
                  height: "1px",
                  background: "rgba(255,255,255,0.4)",
                }}
              />
              <span>ساخته‌شده برای شما</span>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <h1
              className="hero-title"
              style={{
                color: "#fff",
                fontSize: "clamp(2.6rem, 6vw, 4.2rem)",
                fontWeight: 900,
                lineHeight: 1.25,
                letterSpacing: "-1px",
                marginBottom: "26px",
              }}
            >
              دنیای تکنولوژی
              <br />
              <span
                style={{
                  background: "linear-gradient(135deg, #ffffff, #a5d8ff)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                برای زندگی بهتر.
              </span>
            </h1>
          </Reveal>

          <Reveal delay={220}>
            <p
              className="hero-body"
              style={{
                color: "rgba(255,255,255,0.85)",
                fontSize: "var(--font-size-lg)",
                lineHeight: 2,
                maxWidth: "480px",
                marginBottom: "38px",
              }}
            >
              موبایل، لپ‌تاپ و لوازم جانبی را با ضمانت اصالت کالا، بهترین قیمت و
              ارسال سریع به سراسر کشور تهیه کنید.
            </p>
          </Reveal>

          <Reveal delay={320}>
            <Link
              to="/products"
              className="hero-cta"
              style={{
                color: "#fff",
                fontSize: "var(--font-size-lg)",
                fontWeight: 700,
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: "12px",
                borderBottom: "1px solid rgba(255,255,255,0.5)",
                paddingBottom: "6px",
              }}
            >
              مشاهده محصولات
              <span
                className="hero-cta-arrow"
                style={{ display: "inline-flex" }}
              >
                <Icon name="arrowLeft" size={20} />
              </span>
            </Link>
          </Reveal>

          {/* اسکرول + دات‌ها */}
          <Reveal delay={420}>
            <div
              className="hero-bottom"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginTop: "64px",
                maxWidth: "440px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                  color: "rgba(255,255,255,0.7)",
                  fontSize: "0.8rem",
                  letterSpacing: "0.14em",
                }}
              >
                <span
                  style={{
                    position: "relative",
                    display: "inline-block",
                    width: "1px",
                    height: "34px",
                    background: "rgba(255,255,255,0.25)",
                    overflow: "hidden",
                  }}
                >
                  <span
                    style={{
                      position: "absolute",
                      left: 0,
                      top: 0,
                      width: "100%",
                      height: "100%",
                      background: "#fff",
                      animation: "scrollLine 1.8s ease-in-out infinite",
                    }}
                  />
                </span>
              </div>

              <div
                style={{ display: "flex", gap: "8px", alignItems: "center" }}
              >
                {[0, 1, 2, 3, 4].map((i) => (
                  <span
                    key={i}
                    style={{
                      width: i === 0 ? "22px" : "6px",
                      height: "6px",
                      borderRadius: "50px",
                      background: i === 0 ? "#fff" : "rgba(255,255,255,0.3)",
                      transition: "all 0.3s ease",
                    }}
                  />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

// ======================================================
// پیشنهاد ویژه
// ======================================================
function SpecialOffer() {
  return (
    <section
      className="home-section"
      style={{ padding: "30px 20px 90px", background: "var(--color-bg-white)" }}
    >
      <div className="container--plain">
        <Reveal>
          <div
            className="offer-card"
            style={{
              overflow: "hidden",
              background:
                "linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 55%, var(--blue-800) 100%)",
              borderRadius: "28px",
              padding: "64px 40px",
              textAlign: "center",
              color: "var(--color-bg-white)",
              boxShadow: "var(--shadow-hero)",
            }}
          >
            <h2
              style={{
                fontSize: "clamp(1.7rem, 3.5vw, 2.5rem)",
                fontWeight: 800,
                marginBottom: "16px",
                letterSpacing: "-0.3px",
              }}
            >
              تا ۳۰٪ تخفیف روی محصولات منتخب
            </h2>
            <p
              style={{
                maxWidth: "520px",
                margin: "0 auto 30px",
                opacity: 0.93,
                lineHeight: 1.9,
                fontSize: "var(--font-size-xl)",
              }}
            >
              فرصت را از دست ندهید و جدیدترین محصولات را با قیمت ویژه تهیه کنید.
            </p>
            <Link
              to="/products?filter=discount"
              className="btn-white"
              style={{
                display: "inline-block",
                padding: "14px 36px",
                background: "var(--color-bg-white)",
                color: "var(--color-primary-dark)",
                borderRadius: "50px",
                fontWeight: 800,
                textDecoration: "none",
                boxShadow: "0 12px 30px rgba(0,0,0,0.15)",
              }}
            >
              مشاهده محصولات تخفیفی
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ======================================================
// Home
// ======================================================
export default function Home() {
  usePageTitle();
  const { products } = useProducts();
  const { categories } = useCategories();

  const featuredProducts = products.filter((p) => p.isFeatured).slice(0, 4);
  const newProducts = products.filter((p) => p.isNew).slice(0, 4);
  const discountProducts = products
    .filter((p) => p.oldPrice && p.oldPrice > p.price)
    .slice(0, 4);

  return (
    <div style={{ overflowX: "hidden" }}>
      <HeroSection />

      <ProductSection
        bg="var(--color-bg)"
        title="محصولات ویژه"
        subtitle="جدیدترین و محبوب‌ترین محصولات فروشگاه"
        products={featuredProducts}
        to="/products"
        cta="مشاهده همه محصولات"
      />

      <ProductSection
        bg="var(--color-bg-white)"
        title="محصولات جدید"
        subtitle="تازه‌ترین محصولات اضافه‌شده به فروشگاه"
        products={newProducts}
        to="/products?filter=new"
        cta="مشاهده همه محصولات جدید"
      />

      <ProductSection
        bg="var(--color-bg)"
        title="محصولات تخفیفی"
        subtitle="محصولات با بیشترین تخفیف"
        products={discountProducts}
        to="/products?filter=discount"
        cta="مشاهده همه محصولات تخفیفی"
      />

      <SpecialOffer />

      {/* ===== استایل‌های سراسری ===== */}
      <style>{`
        @keyframes scrollLine {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }

        * {
          -webkit-tap-highlight-color: transparent;
        }

        @media (hover: hover) {
          .hero-cta {
            transition: borderColor 0.25s ease;
          }
          .hero-cta:hover {
            border-color: #fff;
          }
          .hero-cta .hero-cta-arrow {
            transition: transform 0.25s ease;
          }
          .hero-cta:hover .hero-cta-arrow {
            transform: translateX(-6px);
          }

          .btn-outline {
            transition: transform 0.25s ease, background 0.25s ease, borderColor 0.25s ease;
          }
          .btn-outline:hover {
            transform: translateY(-3px);
            background: var(--color-primary-tint-10);
            border-color: var(--color-primary);
          }

          .btn-white {
            transition: transform 0.25s ease, boxShadow 0.25s ease;
          }
          .btn-white:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 32px rgba(0, 0, 0, 0.2);
          }

          .home-product-grid > * {
            transition: transform 0.3s ease, boxShadow 0.3s ease;
          }
          .home-product-grid > *:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 32px rgba(15, 23, 42, 0.12);
          }
        }

        @media (hover: none) {
          .btn-outline:active,
          .btn-white:active {
            transform: scale(0.95);
          }
          .home-product-grid > *:active {
            transform: scale(0.97);
          }
        }

        /* ===== موبایل ===== */
        @media (max-width: 640px) {
          .hero-section {
            min-height: 100svh !important;
            align-items: flex-end !important;
          }

          /* اورلی عمودی — پایین تیره‌تر */
          .hero-overlay {
            background:
              linear-gradient(180deg, rgba(15,23,42,0.35) 0%, rgba(15,23,42,0.55) 50%, rgba(13,27,62,0.94) 100%) !important;
          }

          .hero-container {
            padding: 90px 24px 44px !important;
            max-width: none !important;
          }

          .hero-title {
            font-size: 2.2rem !important;
          }

          /* حذف متا و متن توضیحی روی موبایل */
          .hero-meta {
            display: none !important;
          }
          .hero-body {
            display: none !important;
          }

          .hero-bottom {
            margin-top: 48px !important;
            max-width: none !important;
          }

          /* بقیه سکشن‌ها و گرید دوستونه */
          .home-section {
            padding: 56px 16px !important;
          }
          .home-product-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: 12px !important;
          }
          .offer-card {
            padding: 44px 20px !important;
            border-radius: 20px !important;
          }
        }
      `}</style>
    </div>
  );
}
